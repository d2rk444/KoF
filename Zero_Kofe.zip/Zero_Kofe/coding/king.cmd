;-| AI Motions |--------------------------------------------------------
[Command]
name = "AI_1"
command = U,D,F,F,B,B
time = 1

[Command]
name = "AI_2"
command = U,D,F,F,B,F
time = 1

[Command]
name = "AI_3"
command = U,D,F,F,B,D
time = 1

[Command]
name = "AI_4"
command = U,D,F,F,B,U
time = 1

[Command]
name = "AI_5"
command = U,D,F,F,U,B
time = 1

[Command]
name = "AI_6"
command = U,D,F,F,D,B
time = 1

[Command]
name = "AI_7"
command = U,D,F,F,F,B
time = 1

[Command]
name = "AI_8"
command = D,D,F,F,D,B
time = 1

[Command]
name = "AI_9"
command = D,D,F,F,F,B
time = 1

[Command]
name = "AI_10"
command = F, D, B, U
time = 1

[Command]
name = "AI_11"
command = F, U, B, D
time = 1

[Command]
name = "AI_12"
command = F, F, F, F, F, B, U, U
time = 1

[Command]
name = "AI_13"
command = U, U, D, D, F, F, U
time = 1

[Command]
name = "AI_14"
command = U, D, U, D, U, D
time = 1

[Command]
name = "AI_15"
command = F, F, B, B, U, D, U
time = 1

[Command]
name = "AI_16"
command = B, D, D, U, F, D, D
time = 1

[Command]
name = "AI_17"
command = D, D, U, U, U, U, U, U
time = 1

[Command]
name = "AI_18"
command = D, D, D, D, D, D, D, U, U
time = 1

[Command]
name = "AI_19"
command = D, U, D, D, F, D, D, U, U
time = 1

[Command]
name = "AI_20"
command = D, D, D, D, B, D, D, U, U
time = 1

;-| Super Motions |--------------------------------------------------------
[Command]
name = "death"
command = ~F, D, B, F, a+b
time = 25

[Command]
name = "beam"
command = ~F, D, B, F, x
time = 25

[Command]
name = "beam"
command = ~F, D, B, F, y
time = 25

[Command]
name = "fullscreen"
command = ~D, DF, F, D, DF,F, a+b
time = 25


[Command]
name = "triple"
command = ~D, DF, F, D, DF, F, x
time = 25

[Command]
name = "triple"
command = ~D, DF, F, D, DF, F, y
time = 25

;-| Special Motions |------------------------------------------------------
[Command]
name = "blades"
command = ~D, DF, F, x
time = 20

[Command]
name = "blades2"
command = ~D, DF, F, y
time = 20

[Command]
name = "shadow"
command = ~B, DB, D, DF, F, a
time = 20

[Command]
name = "shadow"
command = ~B, DB, D, DF, F, b
time = 20

[Command]
name = "trap"
command = ~F, DF, D, DB, B, a
time = 20

[Command]
name = "trap"
command = ~F, DF, D, DB, B, b
time = 20

[Command]
name = "proj"
command = ~D, DB, B, x
time = 20

[Command]
name = "proj2"
command = ~D, DB, B, y
time = 20

[Command]
name = "rising"
command = ~F, D, DF, x
time = 15

[Command]
name = "rising2"
command = ~F, D, DF, y
time = 15

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery"
command = x+y
time = 1

[Command]
name = "recovery"
command = c
time = 1

[Command]
name = "rock"
command = a+y
time = 1

[Command]
name = "cd"
command = b+y
time = 1

[Command]
name = "ab"
command = a+x
time = 1

[Command]
name = "abc"
command = a+y+x
time = 1

;-| Dir + Button |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "hold_a"
command = /$a
time = 1

[Command]
name = "hold_b"
command = /$b
time = 1

[Command]
name = "hold_c"
command = /$c
time = 1

[Command]
name = "hold_x"
command = /$x
time = 1

[Command]
name = "hold_y"
command = /$y
time = 1

[Command]
name = "hold_z"
command = /$z
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holddownfwd";Required (do not remove)
command = /$DF
time = 1

[Command]
name = "longjump"
command = ~D, $U
time = 11

[Statedef -1]

;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;--------------------------------------------------------------------------- 
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------
;---------------------------------------------------------------------------

;SUrPRISE ROSE HSDM
[State -1,]
type = ChangeState
value = 3000
triggerall = command = "triple"
triggerall = power >= 1000
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101
trigger4 = stateno = 250 && time = [9,16]
trigger5 = stateno = 225 && time = [7,12]
trigger6 = stateno = 420 && time = [9,14]

;ILLUSION DANCE SDM
[State -1,]
type = ChangeState
value = 3100
triggerall = command = "fullscreen"
triggerall = power >= 2000
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;SILENT FLASH
[State -1,]
type = ChangeState
value = 3200
triggerall = command = "death"
triggerall = power >= 3000
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;ILLUSION DANCE B
[State -1,]
type = ChangeState
value = 3010
triggerall = command = "beam"
triggerall = power >= 1000
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;Trap Shot
[State -1,]
type = ChangeState
value = 1100
triggerall = command = "rising"
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101
trigger4 = stateno = 250 && time = [9,16]
trigger5 = stateno = 225 && time = [7,12]
trigger6 = stateno = 420 && time = [9,14]

;Trap Shot
[State -1,]
type = ChangeState
value = 1110
triggerall = command = "rising2"
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101
trigger4 = stateno = 250 && time = [9,16]
trigger5 = stateno = 225 && time = [7,12]
trigger6 = stateno = 420 && time = [9,14]

;Mirage Kick A
[State -1,]
type = ChangeState
value = 1900
triggerall = command = "proj"
triggerall = numprojid(1040) =0
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;Mirage Kick B
[State -1,]
type = ChangeState
value = 1910
triggerall = command = "proj2"
triggerall = var(9) = 0
triggerall = numprojid(1040) =0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;Tornado Kick B
[State -1,]
type = ChangeState
value = 1800
triggerall = command = "trap"
triggerall = numhelper(1800) = 0
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;Mirage Dance
[State -1,]
type = ChangeState
value = 1700
triggerall = command = "shadow"
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;Venom Strike A
[State -1,]
type = ChangeState
value = 1000
triggerall = command = "blades"
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101
trigger4 = stateno = 250 && time = [9,16]
trigger5 = stateno = 225 && time = [7,12]
trigger6 = stateno = 420 && time = [9,14]

;Venom Strike B
[State -1,]
type = ChangeState
value = 1001
triggerall = command = "blades2"
triggerall = numprojid(1005) = 0
triggerall = var(9) = 0
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101
trigger4 = stateno = 250 && time = [9,16]
trigger5 = stateno = 225 && time = [7,12]
trigger6 = stateno = 420 && time = [9,14]
;---------------------------------------------------------------------------
;Run Fwd 1
[State -1, Run Fwd]
type = ChangeState
value = 100
triggerall = var(22) = 0
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;Run Back
[State -1, Run Back]
type = ChangeState
value = 105
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;Throw 1
[State -1]
type = ChangeState
value = 800
triggerall = command = "y"
triggerall = command = "holdfwd"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = stateno != 100
trigger1 = p2bodydist x < 20
trigger1 = p2statetype != A
trigger1 = p2movetype != H
trigger1 = p2stateno != 5120
trigger1 = ctrl

;Throw 2
[State -1]
type = ChangeState
value = 801
triggerall = command = "b"
triggerall = command = "holdfwd"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = stateno != 100
trigger1 = p2bodydist x < 20
trigger1 = p2statetype != A
trigger1 = p2movetype != H
trigger1 = p2stateno != 5120
trigger1 = ctrl

;Counter
[State -1]
type = ChangeState
value = 305
triggerall = var(22) = 0
triggerall = command = "cd" ^^ command = "z"
trigger1 = (stateno = 150 || stateno = 151) && power >= 1000

; Power charge
;[State -1]
;type = ChangeState
;value = 310
;triggerall = statetype = S
;triggerall = Power < 3000
;triggerall = var(9) = 0
;triggerall = ctrl = 1
;trigger1 = command = "hold_a"
;trigger1 = command = "hold_y"
;trigger1 = command = "hold_x"

; Taunt
[State -1]
type = ChangeState
value = 195
trigger1 = command = "start"
trigger1 = Vel X = 0
trigger1 = stateno != 195
trigger1 = statetype = S
trigger1 = ctrl = 1

;---------------------------------------------------------------------
;-----------------------------------------DODGE
;---------------------------------------------------------------------
; Dodge backward (Kof98)
[State -1]
type = ChangeState
value = 360
triggerall = command = "ab" ^^ command = "c"
triggerall = command = "holdback"
triggerall = var(9) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = (stateno = 150 || stateno = 151) && power >= 1000
trigger3 = stateno = 101

; Dodge forward 98(after dodge forward 99)
[State -1]
type = ChangeState
value = 361
triggerall = command = "ab" ^^ command = "c"
triggerall = var(9) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = (stateno = 150 || stateno = 151) && power >= 1000
trigger3 = stateno = 101

;---------------------------------------------------------------------------
;Standing CD
[State -1]
type = ChangeState
value = 300
triggerall = command = "cd" ^^ command = "z"
trigger1 = statetype != A
trigger1 = ctrl
trigger2 = stateno = 101

;Aerial CD
[State -1]
type = ChangeState
value = 650
triggerall = command = "cd" ^^ command = "z"
trigger1 = statetype = A
trigger1 = ctrl

[State -1,]
type = ChangeState
value = 250
triggerall = command = "x"
triggerall = command = "holdfwd"
;;triggerall = command != "holddown"
trigger1 = stateno = 400 && time = [5,8]
;---------------------------------------------------------------------------
;===========================================================================
;---------------------------------------------------------------------------
;Standing Weak punch
[State -1,]
type = ChangeState
value = 200
triggerall = command = "x"
triggerall = command != "holddown"
;triggerall = p2bodydist x > 19
triggerall = var(9) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101
trigger4 = stateno = 200 && time = [5,8]


;---------------------------------------------------------------------------
;Standing Weak Kick
[State -1]
type = ChangeState
value = 210
triggerall = command = "a"
triggerall = command != "holddown"
;triggerall = p2bodydist x > 19
triggerall = var(9) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101
trigger4 = stateno = 200 && time = [5,8]


;Standing Forward + Weak Kick
;[State -1,]
;type = ChangeState
;value = 245
;triggerall = command = "a"
;triggerall = command != "holddown"
;triggerall = command = "holdfwd"
;triggerall = var(9) = 0
;trigger1 = stateno = 205 && time = [6,11]
;trigger2 = stateno = 215 && time = [4,9]
;trigger3 = stateno = 225 && time = [8,18]
;trigger4 = stateno = 235 && time = [5,18]
;trigger5 = stateno = 400 && time = [4,8]
;trigger6 = stateno = 420 && time = [6,17]

;---------------------------------------------------------------------------
;Standing Hard punch
[State -1]
type = ChangeState
value = 220
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = p2bodydist x > 19
triggerall = var(9) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;Standing Close Hard punch
[State -1]
type = ChangeState
value = 225
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = var(9) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;---------------------------------------------------------------------------
;forward Strong Kick after Crouch Strong punch


;Standing Hard Kick
[State -1]
type = ChangeState
value = 230
triggerall = command = "b"
triggerall = var(9) = 0
triggerall = command != "holddown"
triggerall = p2bodydist x > 19
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;Standing Close Hard Kick
[State -1]
type = ChangeState
value = 235
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = var(9) = 0
trigger1 = statetype = S
trigger1 = ctrl
trigger2 = stateno = 52
trigger2 = animelem = 1, >= 1
trigger3 = stateno = 101

;---------------------------------------------------------------------------
;Crouching Weak punch
[State -1]
type = ChangeState
value = 400
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = var(9) = 0
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 101
trigger3 = stateno = 400 && time = [5,8]
;---------------------------------------------------------------------------
;Crouching weak Kick
[State -1]
type = ChangeState
value = 410
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = var(9) = 0
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 101
trigger3 = stateno = 400 && time = [5,8]
;---------------------------------------------------------------------------
;Crouching hard punch
[State -1]
type = ChangeState
value = 420
triggerall = command = "y"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 101

;---------------------------------------------------------------------------
;Crouching hard kick
[State -1]
type = ChangeState
value = 430
triggerall = command = "b"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = stateno = 101

;---------------------------------------------------------------------------
;Jumping Weak punch
[State -1]
type = ChangeState
value = 600
triggerall = command = "x"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;Jumping Kick
[State -1]
type = ChangeState
value = 610
triggerall = command = "a"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;Jumping strong punch
[State -1]
type = ChangeState
value = 620
triggerall = command = "y"
trigger1 = statetype = A
trigger1 = ctrl

;Jumping strong Kick
[State -1]
type = ChangeState
value = 630
triggerall = command = "b"
trigger1 = statetype = A
trigger1 = ctrl

;-------------------------------------------------------
;----------------------------AI-------------------------
;-------------------------------------------------------

;Nightmare Pressure HSDM
[State -1]
type = ChangeState
value = 3200
triggerall = var(9) = 1
triggerall = power >= 3000
triggerall = statetype != A
triggerall = roundstate = 2
;triggerall = p2stateno != [5080, 5090]
;triggerall = p2stateno != [5100, 5110]
;triggerall = p2stateno != [5121, 5160]
;triggerall = p2stateno != [5170, 5200]
trigger1 = p2bodydist x <= 55 && (stateno=330||stateno=230) && movehit && random <= 40
trigger2 = (p2bodydist x = [0,200]) && p2bodydist y <= -30 && p2statetype = A &&  ctrl && random <=85
;&& p2movetype = H
;trigger3 = ctrl && p2stateno = 1045 && FrontEdgeBodyDist>=70 && random <= 65
trigger3 = p2bodydist x >= 20 && (p2stateno = 360 || p2stateno = 361) && ctrl && random <=100
trigger4 = ((stateno = [231,299])||(stateno = [400,519])) && MoveHit && random = [874,883]
trigger5 = p2stateno = 5120 && time >= 12 && p2bodydist x < 45 && random > 985 && ctrl
trigger6 = (p2bodydist x = [0,200]) && p2statetype != A && ctrl && random <= 100

;Dark Gravity (ground) DM
[State -1]
type = ChangeState
value = 3000
triggerall = var(9) = 1 && random > 250
triggerall = p2stateno != [5030,5120]
triggerall = power >= 1000
triggerall = power <= 2000
triggerall = roundstate = 2
triggerall = ctrl && statetype != A
trigger1 = p2bodydist x =[1,30]
trigger1 = p2bodydist y > -65 && enemy,vel y > -6
trigger1 = (p2movetype = A||p2stateno = [100,102])
;(enemy,ctrl = 0||p2movetype = A||p2stateno = [100,102])
trigger2 = (ctrl && statetype != A) || stateno = 100
trigger2 = p2stateno = 2207 || (p2stateno = [1800,1830])
trigger2 = p2movetype = H && p2bodydist x < 140 && p2statetype !=A
;&& p2bodydist y < -25
trigger3 = movecontact && var(38) > 0 && time = [19,22]
trigger3 = statetype != A && p2statetype != A && stateno = 1000
trigger4 = p2stateno = 1830 && random <=350
trigger4 = p2bodydist x <= 40


;Final Judgement SDM
[State -1]
type = ChangeState
value = 3100
triggerall = p2stateno != 5040
;&& p2statetype != A
triggerall = power >= 2000
triggerall = var(9) = 1 && statetype != A
triggerall = roundstate = 2
trigger1 = (p2bodydist x = [80,220]) && p2statetype != L && p2stateno != 5201 && ctrl && random <= 100
trigger2 = stateno = 500 && animelemtime(4) >=0 && animelemtime(5) < 0 && movecontact && random <= 800
trigger2 = stateno = 235 && animelemtime(7) >=0 && animelemtime(8) < 0 && movehit && p2statetype !=A && random <= 100
trigger3 = stateno = 320 && animelemtime(3) >=0 && animelemtime(4) < 0 && movehit && random <= 100
trigger4 = p2stateno = 1830 && random <=250

;Execution DM
[State -1]
type = ChangeState
value = 3010
triggerall = p2stateno != 5040 && p2statetype != A
triggerall = power >= 1000
triggerall = power <= 2000
triggerall = var(9) = 1 && statetype != A
triggerall = roundstate = 2
trigger1 = (p2bodydist x = [80,120]) && p2statetype != A && p2statetype != L && p2stateno != 5201 && ctrl && random <= 100
trigger2 = stateno = 500 && animelemtime(4) >=0 && animelemtime(5) < 0 && movecontact && random <= 800
trigger2 = stateno = 235 && animelemtime(7) >=0 && animelemtime(8) < 0 && movehit && p2statetype !=A && random <= 100
trigger3 = stateno = 320 && animelemtime(3) >=0 && animelemtime(4) < 0 && movehit && random <= 100
trigger4 = p2stateno = 1830 && random <=350
trigger4 = p2bodydist x >= 80


[State -1]
type = ChangeState
value = 1800
triggerall = Var(9) = 1 && statetype!=A && ctrl && p2bodydist x<=200 && random <= 100
triggerall = roundstate = 2 && p2statetype != L
triggerall = numhelper(1800) = 0 && prevstateno != 1800
trigger1 = p2bodydist x<=200 && p2statetype !=A && random <= 150
trigger2 = p2bodydist x<=130 && p2movetype=A&& random <= 100
trigger3 = p2bodydist x<=70 && p2movetype=H && random <= 100
trigger4 = (stateno = 1053 && animtime>=15) && p2bodydist x<=70 && p2statetype !=A && random <= 100
trigger5 = (stateno = 1055 && animtime>=15) && p2bodydist x<=70 && p2statetype !=A && random <= 100
;trigger6 = stateno = 6666
;trigger7 = stateno = 1054

;Slash Kick A
[State -1]
type = ChangeState
value = 1700
triggerall = p2stateno != 5040 && p2statetype != A
triggerall = var(9) = 1 && statetype != A
trigger1 = p2bodydist x <= 130 && p2statetype != A && p2statetype != L && p2stateno != 5201 && ctrl && random <= 100
trigger2 = stateno = 500 && animelemtime(4) >=0 && animelemtime(5) < 0 && movecontact && random <= 400
trigger2 = stateno = 235 && animelemtime(7) >=0 && animelemtime(8) < 0 && movehit && p2statetype !=A && random <= 100
trigger3 = stateno = 320 && animelemtime(3) >=0 && animelemtime(4) < 0 && movehit && random <= 100


;Genocide Cutter a
[State -1]
type = ChangeState
value = 1100
triggerall = var(9) = 1
triggerall = statetype != A
triggerall = ((p2stateno != [1054,1055]) && (p2stateno != [5030,5069]))
triggerall = p2stateno != [5080, 5090]
triggerall = p2stateno != [5100, 5110]
triggerall = p2stateno != [5120, 5160]
triggerall = p2stateno != [5170, 5200]
trigger1 = (p2bodydist x = [-20,90]) && (p2bodydist y = [-80,-10]) && p2statetype = A && ctrl && random <= 80
trigger2 = ((stateno = [200,210])||(stateno = [300,320])) && p2bodydist x <= 34 && movehit && random <=20
trigger3 = p2bodydist x <= 28 && ctrl && random <=13
trigger4 = p2stateno = 5070 && p2bodydist x <= 20 && ctrl && random <= 70

;Genocide Cutter b
[State -1]
type = ChangeState
value = 1110
triggerall = var(9) = 1
triggerall = statetype != A
triggerall = ((p2stateno != [1054,1055]) && (p2stateno != [5030,5069]))
triggerall = p2stateno != [5080, 5090]
triggerall = p2stateno != [5100, 5110]
triggerall = p2stateno != [5120, 5160]
triggerall = p2stateno != [5170, 5200]
trigger1 = (p2bodydist x = [-20,90]) && (p2bodydist y = [-80,-10]) && p2statetype = A && ctrl && random <= 100
trigger2 = ((stateno = [200,210])||(stateno = [300,320])) && p2bodydist x <= 34 && movehit && random <=50
trigger3 = p2bodydist x <= 28 && ctrl && random <=13
trigger4 = p2stateno = 5070 && p2bodydist x <= 20 && ctrl && random <= 150
trigger5 = p2movetype = A && ctrl
trigger5 = p2statetype != A || p2stateno = 1830
trigger5 = p2bodydist x < 40
;trigger6 = p2stateno = 1830 && random <=350
;trigger6 = p2bodydist x < 40

;Reppuken a
[State -1]
type = ChangeState
value = 1900
triggerall = p2stateno != 5040 && p2statetype != A
triggerall = var(9) = 1 && statetype != A
triggerall = roundstate = 2 && numproj = 0
trigger1 = (p2bodydist x = [150,240]) && p2statetype != A && p2statetype != L && p2stateno != 5201 && ctrl && random <= 100
trigger2 = stateno = 500 && animelemtime(4) >=0 && animelemtime(5) < 0 && movecontact && random <= 500
trigger2 = stateno = 235 && animelemtime(7) >=0 && animelemtime(8) < 0 && movehit && p2statetype !=A && random <= 100
trigger3 = stateno = 320 && animelemtime(3) >=0 && animelemtime(4) < 0 && movehit && random <= 100

;Reppuken b
[State -1]
type = ChangeState
value = 1910
triggerall = p2stateno != 5040 && p2statetype != A
triggerall = var(9) = 1 && statetype != A
triggerall = roundstate = 2 && numproj = 0
trigger1 = (p2bodydist x = [150,240]) && p2statetype != A && p2statetype != L && p2stateno != 5201 && ctrl && random <= 100
trigger2 = stateno = 500 && animelemtime(4) >=0 && animelemtime(5) < 0 && movecontact && random <= 500
trigger2 = stateno = 235 && animelemtime(7) >=0 && animelemtime(8) < 0 && movehit && p2statetype !=A && random <= 100
trigger3 = stateno = 320 && animelemtime(3) >=0 && animelemtime(4) < 0 && movehit && random <= 100

;Tornado Kick A
[State -1]
type = ChangeState
value = 1000
triggerall = var(9) = 1
triggerall = statetype != A
triggerall = p2stateno != [5080, 5090]
triggerall = p2stateno != [5100, 5110]
triggerall = p2stateno != [5121, 5160]
triggerall = p2stateno != [5170, 5200]
trigger1 = p2bodydist x <= 55 && (stateno=330||stateno=230) && movehit && random <= 40
trigger2 = (p2bodydist x = [-20,30]) && p2bodydist y <= -30 && p2statetype = A &&  ctrl && random <=85 && p2movetype = H
trigger3 = ctrl && p2stateno = 1045 && FrontEdgeBodyDist>=70 && random <= 65
trigger4 = ((stateno = [231,299])||(stateno = [400,519])) && MoveHit && random = [874,883]
trigger5 = p2stateno = 5120 && time >= 12 && p2bodydist x < 45 && random > 985 && ctrl
trigger6 = (p2bodydist x = [-20,70]) && p2statetype != A &&  ctrl && random <= 20

;Tornado Kick B
[State -1]
type = ChangeState
value = 1001
triggerall = var(9) = 1
triggerall = roundstate = 2
triggerall = statetype != A
triggerall = p2stateno != [5080, 5090]
triggerall = p2stateno != [5100, 5110]
triggerall = p2stateno != [5120, 5160]
triggerall = p2stateno != [5170, 5200]
triggerall = ((p2stateno != [1054,1055]) && (p2stateno != [5030,5069]))
trigger1 = (p2bodydist x = [-20,90]) && (p2bodydist y = [-110,-10]) && p2statetype = A && ctrl && p2movetype = A
trigger1 = random = [270,300]
trigger2 = ((stateno = [200,210])||(stateno = [300,320])) && p2bodydist x <= 34 && movehit && random = [60,100]
trigger3 = p2bodydist x <= 28 && ctrl && random = [800,815]
trigger4 = ((stateno = [231,299])||(stateno = [400,521])) && MoveHit && p2bodydist x < 32 && random = [670,679]
;trigger5 = p2stateno = 1830 && random <=350
;trigger5 = p2bodydist x <= 80 && p2bodydist x < 40

[State -1]
type = ChangeState
value = 1800
triggerall = Var(9) = 1 && statetype!=A && ctrl && p2bodydist x<=200 && random <= 100
triggerall = roundstate = 2
triggerall = numhelper(1800) = 0 && prevstateno != 1800
trigger1 = p2bodydist x<=200 && p2statetype !=A && random <= 150
trigger2 = p2bodydist x<=130 && p2movetype=A&& random <= 100
trigger3 = p2bodydist x<=70 && p2movetype=H && random <= 100
trigger4 = (stateno = 1053 && animtime>=15) && p2bodydist x<=70 && p2statetype !=A && random <= 100
trigger5 = (stateno = 1055 && animtime>=15) && p2bodydist x<=70 && p2statetype !=A && random <= 100

;--------------------------------------------------

;Roll Backward
[State -1]
type = ChangeState
value = 360
triggerall = var(9) && statetype != A && ctrl && p2movetype = A && random <= 250
trigger1 = p2bodydist x <= 90 && random <= 250
trigger2 = stateno = 400 && p2bodydist x <= 400 && random <= 400

;Roll Forward
[State -1]
type = ChangeState
value = 361
triggerall = var(9) && statetype != A && ctrl
trigger1 = p2bodydist x <= 240 && p2movetype = A && random <= 150

;Run Forward
[State -1]
type = ChangeState
value = 100
triggerall = var(9) = 1
triggerall = p2movetype != A
triggerall = p2statetype != L
triggerall = P2bodydist X >= 40
trigger1 = stateno = 0
trigger1 = stateno != 100
trigger1 = ctrl

[State -1]
type = ChangeState
value = 38
triggerall = var(9) = 1
triggerall = p2bodydist x >= 140
triggerall = random <= 30
triggerall = p2statetype != L
trigger1 = statetype != A
trigger1 = ctrl = 1

;Jump
[State -1]
type = ChangeState
value = 40
triggerall = stateno != 40
triggerall = P2life != 0
triggerall = statetype != A
triggerall = var(9) = 1
triggerall = p2statetype != A
triggerall = frontedgebodydist >= 40
triggerall = p2movetype != H
triggerall = ctrl
trigger1 = p2stateno = 5120
trigger1 = P2bodydist X >= 60
trigger1 = random <= 100
trigger1 = statetype != A
trigger2 = p2bodydist x = [40,70]
trigger2 = random <=100
trigger2 = p2movetype != H
trigger3 = p2bodydist x = [0,50]
trigger3 = random <=200
trigger3 = p2statetype = C
trigger3 = p2movetype != H

[State -1]
type = ChangeState
value = 39
triggerall = stateno != 40
triggerall = frontedgebodydist >= 40
triggerall = p2movetype != H
triggerall = var(9) = 1
triggerall = statetype != A
triggerall = ctrl = 1
trigger1 = p2bodydist x = [71,100]
trigger1 = random <=80
trigger1 = p2movetype != H
trigger2 = p2bodydist x = [75,90]
trigger2 = random <=50
trigger2 = p2statetype = C
trigger2 = p2movetype != H

; ==========================
; AI Standing Guard
; ==========================
[State -1]
type = ChangeState
value = 120 ;Default standing guard state
triggerall = var(9) = 1 ;AI trigger used
triggerall = Statetype != A ;Player is not in the air
triggerall = P2statetype != C ;Player is not crouching
triggerall = Statetype = S ;Player is currently standing
triggerall = P2Movetype = A ;Opponent is attacking
triggerall = Pos Y != [-1,-999]
triggerall = ctrl = 1
trigger1 = random <= 800 ;triggers at 80% probability
;trigger1 = 1



;Air block
[State -1]
type = ChangeState
value = 122
triggerall = var(9) = 1 ;AI trigger used
triggerall = Statetype = A ;Player is not in the air
triggerall = P2statetype != C ;Player is not crouching
triggerall = Statetype = S ;Player is currently standing
triggerall = P2Movetype = A ;Opponent is attacking
triggerall = Pos Y != [1,999]
triggerall = ctrl = 1
trigger1 = random <= 800 ;triggers at 80% probability

; =============================
; AI Stand to Crouch Guard Transition
; =============================
[State -1]
type = ChangeState
triggerall = var(9) = 1
triggerall = StateType != A
triggerall = P2statetype = C
triggerall = P2Movetype = A
triggerall = Pos Y != [-1,-999]
trigger1 = stateno = 150
trigger1 = 1
value = 151

; =============================
; AI Crouching Guard
; =============================
[State -1]
type = ChangeState
value = 121
triggerall = var(9) = 1
triggerall = StateType != A
triggerall = P2statetype = C
triggerall = P2Movetype = A
triggerall = Pos Y != [-1,-999]
triggerall = ctrl = 1
trigger1 = random <= 800
;trigger1 = 1
trigger1 = p2bodydist x > 50

; =============================
; AI Crouch to Stand Guard Transition
; =============================
[State -1]
type = ChangeState
triggerall = var(9) = 1
triggerall = Statetype != A
triggerall = P2statetype != C
triggerall = P2Movetype = A
trigger1 = 1
trigger1 = stateno = 151
value = 150

;Recovery
[State -1]
type = ChangeState
value = 370
triggerall = var(9) = 1
triggerall = stateno >= 5030
triggerall = CanRecover
triggerall = alive
trigger1 = Vel Y > 0
trigger1 = Pos Y >= -30

;Throw 1
[State -1]
type = changestate
value = 800
triggerall = Var(9) = 1 && statetype!=A && ctrl && p2bodydist x<=60
triggerall = p2movetype != A
triggerall = roundstate = 2
triggerall = (p2stateno != [120,159]) && p2movetype != H
trigger1 = p2bodydist x<=40 && p2statetype !=A && random <= 350
;trigger2 = p2bodydist x<=40 && p2movetype=H && random<= 300
trigger2 = (stateno = 1053 && animtime>=15) && p2bodydist x<=70 && p2statetype !=A && random <= 350
trigger3 = (stateno = 1055 && animtime>=15) && p2bodydist x<=70 && p2statetype !=A && random <= 300

;Throw 2
[State -1]
type = changestate
value = 801
triggerall = Var(9) = 1 && statetype!=A && ctrl && p2bodydist x<=60
triggerall = p2movetype != A
triggerall = roundstate = 2
triggerall = (p2stateno != [120,159]) && p2movetype != H
trigger1 = p2bodydist x<=40 && p2statetype !=A && random <= 350
;trigger2 = p2bodydist x<=40 && p2movetype=H && random<= 300
trigger2 = (stateno = 1053 && animtime>=15) && p2bodydist x<=70 && p2statetype !=A && random <= 350
trigger3 = (stateno = 1055 && animtime>=15) && p2bodydist x<=70 && p2statetype !=A && random <= 300

;Taunt
[State -1]
type = ChangeState
value = 195
triggerall = var(9) && p2movetype != A && p2bodydist x > 150 && random <= 50
triggerall = stateno != 100 && statetype = S && ctrl && stateno !=195
trigger1 = p2life <= (life - 300)
